# Learn React + Redux Toolkit + Redux Saga (TypeScript)

A small app made of 5 lessons, each building on the last. Every file is heavily
commented. Read the code alongside the running app.

## Run it

```bash
npm install
npm run dev        # http://localhost:5173
npm test           # reducer + saga tests (vitest)
npm run typecheck
```

Also install the **Redux DevTools** browser extension. `configureStore` connects
to it automatically, and you can see every action and the state before and after
it. (The app also has its own Action Log sidebar for the same purpose.)

---

## The mental model, coming from Context

| With React Context | With Redux |
| --- | --- |
| `createContext` + a `<Provider>` per feature | **One** `store`, **one** `<Provider store={store}>` at the root |
| `useState` / `useReducer` inside each provider | A **slice** per feature (`createSlice`) |
| `useContext(MyContext)` | `useAppSelector(state => state.feature.thing)` |
| Calling a setter / dispatch from context | `dispatch(someAction(payload))` |
| Async work in `useEffect` or event handlers | A **saga** that listens for actions |
| Every consumer re-renders when the value changes | A component re-renders only when **its selected value** changes |
| State disappears when the provider unmounts | The store lives outside React, so state survives |
| A reducer only sees its own provider’s actions | **Every** action goes to **every** slice reducer |

## How data flows

```
 component ── dispatch(action) ──▶ store
                                     │
                      ┌──────────────┴───────────────┐
                      ▼  (1st)                       ▼  (2nd)
                  reducers                         sagas
           pure: compute new state      side effects: API calls, timers, etc.
                      │                              │
                      ▼                              │ put(anotherAction)
                  new state  ◀───────────────────────┘ (goes through the same flow)
                      │
                      ▼
   useAppSelector re-renders the components whose selected data changed
```

Two rules to remember:

1. **Reducers** are pure and synchronous. No API calls, no `Math.random()`, no `Date.now()`.
2. **Sagas** do all the messy async work, then report results by dispatching more actions with `put`.

---

## The lessons

| # | Lesson | New concepts | Files to read |
| --- | --- | --- | --- |
| 1 | Counter | store, slice, actions, `useAppSelector`, `useAppDispatch`; Context vs Redux side by side | `features/counter/*`, `app/store.ts`, `app/hooks.ts`, `main.tsx` |
| 2 | Todos | payloads, `prepare` callbacks, `createSelector` for derived data, what *not* to put in Redux | `features/todos/*` |
| 3 | Fetch users | your first saga: `takeLatest`, `call`, `put`, `select`, request/success/failure actions, testing sagas | `features/users/*`, `app/rootSaga.ts` |
| 4 | Search | debouncing with `takeLatest` + `delay`, automatic cancellation of stale requests | `features/search/*` |
| 5 | Polling | hand-written watcher loops: `take`, `race`, `cancelled`, background tasks | `features/price/*` |
| ★ | Action Log | `extraReducers` + `addMatcher`: a slice reacting to *every* action | `features/actionLog/*` |

## Saga effects cheat sheet

All imported from `redux-saga/effects`. You `yield` them inside a `function*`.

| Effect | What it does | Blocks the saga? |
| --- | --- | --- |
| `call(fn, ...args)` | Call a function (usually one returning a Promise) and wait for the result | Yes |
| `put(action)` | Dispatch an action | No |
| `select(selector)` | Read from the current state | No |
| `delay(ms)` | Wait | Yes |
| `take(pattern)` | Pause until a matching action is dispatched | Yes |
| `takeEvery(pattern, worker)` | Start `worker` for **every** matching action, in parallel | No |
| `takeLatest(pattern, worker)` | Start `worker`, **cancelling** any previous one still running | No |
| `takeLeading(pattern, worker)` | Start `worker`, **ignoring** new actions until it finishes | No |
| `fork(saga)` | Start a saga in the background | No |
| `all([...])` | Run several effects in parallel and wait for all | Yes |
| `race({ a, b })` | Run effects in parallel; first to finish wins, the rest are cancelled | Yes |
| `cancelled()` | In a `finally` block: “was I cancelled?” | No |

## TypeScript tips

- `RootState` and `AppDispatch` are **inferred** from the store (`app/store.ts`). Don't write them by hand.
- Always use `useAppSelector` / `useAppDispatch` (`app/hooks.ts`), not the untyped originals.
- Give sagas the return type `SagaIterator`.
- TypeScript can't infer what `yield` returns, so annotate the variable:
  `const users: User[] = yield call(api.fetchUsers, ...)`.
  (The library [`typed-redux-saga`](https://github.com/agiledigital/typed-redux-saga) fixes this with `yield*` if you want full inference later.)
- Use the action creator's `.type` as the saga pattern: `takeLatest(fetchUsersRequested.type, worker)`.
- Type a worker's argument with `PayloadAction<T>` to read `action.payload`.

---

## Exercises

Try these once you've read each lesson. Use the Action Log or Redux DevTools to check your work.

1. **Counter**: add an `incrementByAmount(n)` action with a number input. Add a test for it in `counterSlice.test.ts`.
2. **Todos**: add “edit todo text” (double-click to edit). Keep the input value in `useState` and dispatch only on save.
3. **Todos + saga**: save todos to `localStorage`. Write a saga that uses `takeEvery` on the todo actions, then `select(selectTodos)`, then `call([localStorage, 'setItem'], 'todos', JSON.stringify(todos))`.
4. **Users**: add a delete button with an *optimistic update*. Remove the user from state right away, call a fake `deleteUser(id)` API, and put the user back if it fails.
5. **Search**: ignore queries shorter than 2 characters. Then try the built-in `debounce` effect and compare.
6. **Polling**: add a speed selector and read it with `select()` inside the loop. Stop polling automatically after 5 consecutive errors.
7. **Testing**: write a step-by-step test for `handleQueryChanged` in `searchSaga.ts`, using `usersSaga.test.ts` as the model.

---

## Project structure

```
src/
├── main.tsx                  <Provider store={store}> — the one Provider
├── App.tsx                   lesson tabs + Action Log sidebar
├── app/
│   ├── store.ts              configureStore + saga middleware + RootState/AppDispatch types
│   ├── hooks.ts              typed useAppSelector / useAppDispatch
│   └── rootSaga.ts           starts every feature saga
├── api/
│   └── fakeApi.ts            fake backend with delays and failures (works offline)
├── components/               shared UI bits (lesson layout, re-render flash)
└── features/
    ├── counter/              Lesson 1 (+ the Context version for comparison)
    ├── todos/                Lesson 2
    ├── users/                Lesson 3 (+ saga test)
    ├── search/               Lesson 4
    ├── price/                Lesson 5
    └── actionLog/            Bonus: logs every action
```

## Where sagas fit today

Redux Toolkit now recommends **RTK Query** for plain data fetching and the
**listener middleware** for simple “when X happens, do Y” logic. Redux Saga is
still widely used in existing codebases, and it's strongest for complex
workflows: cancellation, races, debouncing, and long-running background
processes like lesson 5. Once you're comfortable here, RTK Query is worth
looking at next.
