import { useEffect, useRef } from 'react'

/**
 * Makes an element briefly glow every time its component re-renders.
 * Used in Lesson 1 to show WHICH components re-render with Context vs Redux.
 */
export function useRenderFlash<T extends HTMLElement>() {
  const ref = useRef<T>(null)

  // No dependency array = runs after every render.
  useEffect(() => {
    ref.current?.animate(
      [{ boxShadow: '0 0 0 3px var(--flash)' }, { boxShadow: '0 0 0 3px transparent' }],
      { duration: 700, easing: 'ease-out' },
    )
  })

  return ref
}
