import type { ReactNode } from 'react'

interface LessonProps {
  title: string
  intro: ReactNode
  files: string[]
  tryIt: ReactNode[]
  children: ReactNode
}

/** Shared layout for each lesson page: explanation, files to read, then the demo. */
export function Lesson({ title, intro, files, tryIt, children }: LessonProps) {
  return (
    <article className="lesson">
      <h2>{title}</h2>
      <div className="intro">{intro}</div>

      <div className="meta">
        <section>
          <h3>Read these files</h3>
          <ul className="files">
            {files.map((f) => (
              <li key={f}>
                <code>{f}</code>
              </li>
            ))}
          </ul>
        </section>
        <section>
          <h3>Try it</h3>
          <ul>
            {tryIt.map((t, i) => (
              <li key={i}>{t}</li>
            ))}
          </ul>
        </section>
      </div>

      <div className="demo">{children}</div>
    </article>
  )
}
