/**
 * A fake backend so the examples work offline.
 *
 * Every function returns a Promise and waits a bit, just like a real
 * `fetch()` call would. Sagas don't care whether a Promise comes from
 * fetch, axios or this file — they just `call()` it and wait.
 */

export interface User {
  id: number
  name: string
  email: string
}

export interface Product {
  id: number
  name: string
  price: number
}

const wait = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms))

// ---------------------------------------------------------------------------
// Lesson 3 — users
// ---------------------------------------------------------------------------

const USERS: User[] = [
  { id: 1, name: 'Ada Lovelace', email: 'ada@example.com' },
  { id: 2, name: 'Alan Turing', email: 'alan@example.com' },
  { id: 3, name: 'Grace Hopper', email: 'grace@example.com' },
  { id: 4, name: 'Linus Torvalds', email: 'linus@example.com' },
  { id: 5, name: 'Margaret Hamilton', email: 'margaret@example.com' },
]

export async function fetchUsers(options: { shouldFail: boolean }): Promise<User[]> {
  await wait(1000)
  if (options.shouldFail) {
    throw new Error('500 Internal Server Error (simulated)')
  }
  return USERS
}

// ---------------------------------------------------------------------------
// Lesson 4 — product search
// ---------------------------------------------------------------------------

const PRODUCTS: Product[] = [
  'Apple', 'Apricot', 'Avocado', 'Banana', 'Blackberry', 'Blueberry',
  'Cherry', 'Coconut', 'Cranberry', 'Date', 'Dragonfruit', 'Fig',
  'Grape', 'Grapefruit', 'Guava', 'Kiwi', 'Lemon', 'Lime', 'Lychee',
  'Mango', 'Melon', 'Nectarine', 'Orange', 'Papaya', 'Passionfruit',
  'Peach', 'Pear', 'Pineapple', 'Plum', 'Pomegranate', 'Raspberry',
  'Strawberry', 'Tangerine', 'Watermelon',
].map((name, i) => ({ id: i + 1, name, price: Math.round((1 + (i % 7) * 0.75) * 100) / 100 }))

export async function searchProducts(query: string): Promise<Product[]> {
  await wait(600)
  const q = query.toLowerCase()
  return PRODUCTS.filter((p) => p.name.toLowerCase().includes(q))
}

// ---------------------------------------------------------------------------
// Lesson 5 — live price (random walk)
// ---------------------------------------------------------------------------

let lastPrice = 100

export async function fetchStockPrice(): Promise<number> {
  await wait(200)
  if (Math.random() < 0.1) {
    throw new Error('Price feed hiccup (10% random failure)')
  }
  lastPrice = Math.max(1, lastPrice + (Math.random() - 0.5) * 4)
  return Math.round(lastPrice * 100) / 100
}
