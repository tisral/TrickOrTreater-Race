/**
 * The same counter, with Redux. Compare with CounterWithContext.tsx.
 *
 * Notice:
 *   - No Provider component here — the single <Provider store={store}> in main.tsx covers everything.
 *   - Each component picks ONLY the data it needs with useAppSelector.
 *     It re-renders only when THAT value changes.
 *   - Components never change state directly. They `dispatch` an action
 *     (a plain object describing what happened), and the reducer decides
 *     how the state changes.
 */
import { useAppDispatch, useAppSelector } from '../../app/hooks'
import { useRenderFlash } from '../../components/useRenderFlash'
import { decrement, increment, reset, selectCount, selectStep, setStep } from './counterSlice'

function CountDisplay() {
  const count = useAppSelector(selectCount) // re-renders only when count changes
  const ref = useRenderFlash<HTMLDivElement>()
  return (
    <div ref={ref} className="box">
      Count: <strong className="big">{count}</strong>
    </div>
  )
}

function StepPicker() {
  const step = useAppSelector(selectStep) // re-renders only when step changes
  const dispatch = useAppDispatch()
  const ref = useRenderFlash<HTMLDivElement>()
  return (
    <div ref={ref} className="box">
      Step:{' '}
      <select value={step} onChange={(e) => dispatch(setStep(Number(e.target.value)))}>
        {[1, 2, 5, 10].map((n) => (
          <option key={n}>{n}</option>
        ))}
      </select>
    </div>
  )
}

function CounterButtons() {
  // `dispatch` never changes, and this component selects no state,
  // so it never needs to re-render.
  const dispatch = useAppDispatch()
  const ref = useRenderFlash<HTMLDivElement>()
  return (
    <div ref={ref} className="box row">
      <button onClick={() => dispatch(decrement())}>−</button>
      <button onClick={() => dispatch(increment())}>+</button>
      <button onClick={() => dispatch(reset())}>Reset</button>
    </div>
  )
}

export function ReduxCounter() {
  return (
    <>
      <CountDisplay />
      <StepPicker />
      <CounterButtons />
    </>
  )
}
