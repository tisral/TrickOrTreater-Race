/**
 * The counter written the way you probably already know: React Context.
 * Compare this file with ReduxCounter.tsx.
 */
import { createContext, useContext, useMemo, useState, type ReactNode } from 'react'
import { useRenderFlash } from '../../components/useRenderFlash'

interface CounterContextValue {
  count: number
  step: number
  increment: () => void
  decrement: () => void
  reset: () => void
  setStep: (step: number) => void
}

const CounterContext = createContext<CounterContextValue | null>(null)

function useCounter() {
  const ctx = useContext(CounterContext)
  if (!ctx) throw new Error('useCounter must be used inside <CounterProvider>')
  return ctx
}

function CounterProvider({ children }: { children: ReactNode }) {
  const [count, setCount] = useState(0)
  const [step, setStep] = useState(1)

  // Even with useMemo, this object changes whenever count OR step changes...
  const value = useMemo(
    () => ({
      count,
      step,
      increment: () => setCount((c) => c + step),
      decrement: () => setCount((c) => c - step),
      reset: () => setCount(0),
      setStep,
    }),
    [count, step],
  )

  // ...and when the value changes, EVERY component that calls useContext(CounterContext)
  // re-renders — even ones that only care about `step`, or only need the functions.
  // (React 19 lets you write <CounterContext value={...}> instead of <CounterContext.Provider value={...}>.)
  return <CounterContext value={value}>{children}</CounterContext>
}

function CountDisplay() {
  const { count } = useCounter()
  const ref = useRenderFlash<HTMLDivElement>()
  return (
    <div ref={ref} className="box">
      Count: <strong className="big">{count}</strong>
    </div>
  )
}

function StepPicker() {
  const { step, setStep } = useCounter()
  const ref = useRenderFlash<HTMLDivElement>()
  return (
    <div ref={ref} className="box">
      Step:{' '}
      <select value={step} onChange={(e) => setStep(Number(e.target.value))}>
        {[1, 2, 5, 10].map((n) => (
          <option key={n}>{n}</option>
        ))}
      </select>
    </div>
  )
}

function CounterButtons() {
  const { increment, decrement, reset } = useCounter()
  const ref = useRenderFlash<HTMLDivElement>()
  return (
    <div ref={ref} className="box row">
      <button onClick={decrement}>−</button>
      <button onClick={increment}>+</button>
      <button onClick={reset}>Reset</button>
    </div>
  )
}

export function CounterWithContext() {
  return (
    <CounterProvider>
      <CountDisplay />
      <StepPicker />
      <CounterButtons />
    </CounterProvider>
  )
}
