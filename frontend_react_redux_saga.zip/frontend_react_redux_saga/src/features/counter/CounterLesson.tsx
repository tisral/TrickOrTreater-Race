import { Lesson } from '../../components/Lesson'
import { CounterWithContext } from './CounterWithContext'
import { ReduxCounter } from './ReduxCounter'

export function CounterLesson() {
  return (
    <Lesson
      title="1. Redux basics — Context vs Redux"
      intro={
        <p>
          The same counter built twice. Each box <span className="flash-word">glows</span> when its
          component re-renders. With Context, every consumer re-renders whenever anything in the
          context value changes. With Redux, each component subscribes to just the slice of state it
          selects.
        </p>
      }
      files={[
        'src/features/counter/CounterWithContext.tsx',
        'src/features/counter/counterSlice.ts',
        'src/features/counter/ReduxCounter.tsx',
        'src/app/store.ts',
        'src/app/hooks.ts',
        'src/main.tsx',
      ]}
      tryIt={[
        'Click + on each side. With Context all three boxes glow; with Redux only the count does.',
        'Change the step. With Redux only the step box re-renders.',
        'Bump both counters, switch to another lesson, then come back. The Context counter reset to 0 because its Provider unmounted. The Redux counter kept its value because the store lives outside the component tree.',
        'Watch the Action Log on the right. Every Redux change starts as a dispatched action.',
      ]}
    >
      <div className="columns">
        <section className="panel">
          <h3>With React Context</h3>
          <CounterWithContext />
        </section>
        <section className="panel">
          <h3>With Redux</h3>
          <ReduxCounter />
        </section>
      </div>
    </Lesson>
  )
}
