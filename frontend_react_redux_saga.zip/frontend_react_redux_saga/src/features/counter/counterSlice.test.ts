/**
 * Reducers are pure functions: (state, action) => newState.
 * That makes them trivial to test. No store, no React, no mocks.
 */
import { describe, expect, it } from 'vitest'
import reducer, { decrement, increment, reset, setStep } from './counterSlice'

describe('counterSlice reducer', () => {
  const initial = reducer(undefined, { type: 'unknown' }) // { value: 0, step: 1 }

  it('has an initial state', () => {
    expect(initial).toEqual({ value: 0, step: 1 })
  })

  it('increments by the current step', () => {
    const withStep = reducer(initial, setStep(5))
    const after = reducer(withStep, increment())
    expect(after.value).toBe(5)
  })

  it('decrements and resets', () => {
    let state = reducer(initial, decrement())
    state = reducer(state, decrement())
    expect(state.value).toBe(-2)
    expect(reducer(state, reset()).value).toBe(0)
  })

  it('never mutates the previous state', () => {
    const after = reducer(initial, increment())
    expect(initial.value).toBe(0) // Immer created a new object
    expect(after).not.toBe(initial)
  })
})
