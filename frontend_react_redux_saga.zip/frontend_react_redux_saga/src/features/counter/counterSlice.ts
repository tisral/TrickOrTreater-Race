/**
 * LESSON 1 — A "slice" of state
 * =============================
 * A slice = the state + reducers + actions for one feature.
 *
 * If you've used `useReducer` with Context, this replaces:
 *   - the `initialState` you passed to useReducer
 *   - the big `switch (action.type)` reducer function
 *   - the action type constants and action creator helpers
 *
 * `createSlice` generates the action creators for you from the reducer names.
 */
import { createSlice, type PayloadAction } from '@reduxjs/toolkit'
import type { RootState } from '../../app/store'

interface CounterState {
  value: number
  step: number
}

const initialState: CounterState = {
  value: 0,
  step: 1,
}

export const counterSlice = createSlice({
  name: 'counter', // used as a prefix for action types: "counter/increment"
  initialState,
  reducers: {
    // It LOOKS like we're mutating state here, but Redux Toolkit uses a library
    // called Immer that turns these "mutations" into safe immutable updates.
    // (In plain Redux / useReducer you'd write `return { ...state, value: state.value + state.step }`.)
    increment(state) {
      state.value += state.step
    },
    decrement(state) {
      state.value -= state.step
    },
    reset(state) {
      state.value = 0
    },
    // `PayloadAction<number>` types the data that comes with the action.
    setStep(state, action: PayloadAction<number>) {
      state.step = action.payload
    },
  },
})

// Action creators, generated for you:
//   increment()  -> { type: 'counter/increment' }
//   setStep(5)   -> { type: 'counter/setStep', payload: 5 }
export const { increment, decrement, reset, setStep } = counterSlice.actions

// Selectors: small functions that read a piece of state.
// Components pass these to `useAppSelector`.
export const selectCount = (state: RootState) => state.counter.value
export const selectStep = (state: RootState) => state.counter.step

// The reducer is what gets registered in the store (see app/store.ts).
export default counterSlice.reducer
