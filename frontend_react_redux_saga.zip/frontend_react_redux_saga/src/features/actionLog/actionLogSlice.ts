/**
 * BONUS — the Action Log sidebar
 * ==============================
 * This slice records every action that goes through the store.
 *
 * It shows something important about Redux: EVERY dispatched action is sent
 * to EVERY slice reducer. Most slices ignore actions they don't recognise,
 * but a slice can also react to actions it doesn't own, using `extraReducers`.
 * (With Context, each provider's reducer only ever sees its own actions.)
 */
import { createSlice, type PayloadAction, type UnknownAction } from '@reduxjs/toolkit'
import type { RootState } from '../../app/store'

export interface LoggedAction {
  id: number
  type: string
  payload?: string
}

interface ActionLogState {
  entries: LoggedAction[] // newest first
  nextId: number
}

const initialState: ActionLogState = { entries: [], nextId: 1 }
const MAX_ENTRIES = 60

const truncate = (s: string, max = 90) => (s.length > max ? `${s.slice(0, max)}…` : s)

// A "type guard" matcher: returns true for every action except Redux's internal ones (@@redux/INIT...).
const isAppAction = (action: UnknownAction): action is PayloadAction<unknown> =>
  !action.type.startsWith('@@')

export const actionLogSlice = createSlice({
  name: 'actionLog',
  initialState,
  reducers: {
    logCleared(state) {
      state.entries = []
    },
  },
  extraReducers: (builder) => {
    // addMatcher(predicate, reducer): run this reducer for any action where predicate() is true.
    builder.addMatcher(isAppAction, (state, action) => {
      state.entries.unshift({
        id: state.nextId,
        type: action.type,
        payload: action.payload === undefined ? undefined : truncate(JSON.stringify(action.payload)),
      })
      state.nextId += 1
      if (state.entries.length > MAX_ENTRIES) state.entries.pop()
    })
  },
})

export const { logCleared } = actionLogSlice.actions
export const selectActionLog = (state: RootState) => state.actionLog.entries

export default actionLogSlice.reducer
