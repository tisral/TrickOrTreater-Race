import { useAppDispatch, useAppSelector } from '../../app/hooks'
import { logCleared, selectActionLog } from './actionLogSlice'

export function ActionLog() {
  const entries = useAppSelector(selectActionLog)
  const dispatch = useAppDispatch()

  return (
    <aside className="action-log">
      <header className="row">
        <h3>Action Log</h3>
        <button className="link" onClick={() => dispatch(logCleared())}>
          clear
        </button>
      </header>
      <p className="muted small">Every action dispatched to the store, newest first.</p>
      <ol>
        {entries.map((entry) => {
          const [slice, name] = entry.type.split('/')
          return (
            <li key={entry.id}>
              <code>
                <span className={`slice slice-${slice}`}>{slice}/</span>
                {name}
              </code>
              {entry.payload !== undefined && <code className="payload">{entry.payload}</code>}
            </li>
          )
        })}
      </ol>
    </aside>
  )
}
