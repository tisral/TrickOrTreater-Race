/**
 * LESSON 5 — Long-running background tasks: take, race, cancelled
 * ==============================================================
 * takeEvery/takeLatest cover most cases. When you need more control, you can
 * write the watcher loop yourself with these lower-level effects:
 *
 *   take(pattern)   -> PAUSE until an action matching `pattern` is dispatched
 *   race({ a, b })  -> run effects at the same time; the first one to finish
 *                      wins and the others are CANCELLED automatically
 *   cancelled()     -> inside `finally`, tells you whether the saga was cancelled
 *
 * The flow:
 *
 *   wait for START ─▶ race( poll forever , wait for STOP ) ─▶ STOP wins, poll is cancelled ─▶ back to waiting for START
 */
import type { SagaIterator } from 'redux-saga'
import { call, cancelled, delay, put, race, take } from 'redux-saga/effects'

import * as api from '../../api/fakeApi'
import { pollingStarted, pollingStopped, priceFailed, priceReceived } from './priceSlice'

const POLL_INTERVAL_MS = 1000

function* pollPrice(): SagaIterator {
  try {
    // An infinite loop is fine in a saga. Each `yield` pauses the generator,
    // so it never blocks the browser.
    while (true) {
      try {
        const price: number = yield call(api.fetchStockPrice)
        yield put(priceReceived(price))
      } catch (error) {
        // One failed request shouldn't kill the whole polling loop, so we
        // catch it here, report it, and keep going.
        yield put(priceFailed(error instanceof Error ? error.message : 'Unknown error'))
      }
      yield delay(POLL_INTERVAL_MS)
    }
  } finally {
    // `finally` runs when the loop ends for any reason, including cancellation.
    // This is where you'd close a WebSocket, clear a timer, etc.
    if (yield cancelled()) {
      console.log('[priceSaga] polling was cancelled — cleaning up')
    }
  }
}

export function* priceSaga(): SagaIterator {
  while (true) {
    // 1. Sleep until someone dispatches pollingStarted().
    //    While polling is running we're not at this line, so extra
    //    pollingStarted actions are simply ignored.
    yield take(pollingStarted.type)

    // 2. Run the poll loop and wait for pollingStopped at the same time.
    //    pollPrice never finishes on its own, so stop always wins,
    //    and redux-saga then cancels pollPrice for us.
    yield race({
      poll: call(pollPrice),
      stop: take(pollingStopped.type),
    })

    // 3. Loop back to step 1 and wait for the next start.
  }
}
