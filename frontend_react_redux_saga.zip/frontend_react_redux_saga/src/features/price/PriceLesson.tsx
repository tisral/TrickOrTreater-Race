import { useAppDispatch, useAppSelector } from '../../app/hooks'
import { Lesson } from '../../components/Lesson'
import { pollingStarted, pollingStopped, selectPrice } from './priceSlice'

function Sparkline({ values }: { values: number[] }) {
  if (values.length < 2) return <div className="sparkline empty muted">Waiting for data…</div>

  const width = 320
  const height = 70
  const min = Math.min(...values)
  const max = Math.max(...values)
  const range = max - min || 1
  const points = values
    .map((v, i) => {
      const x = (i / (values.length - 1)) * width
      const y = height - ((v - min) / range) * (height - 8) - 4
      return `${x.toFixed(1)},${y.toFixed(1)}`
    })
    .join(' ')

  return (
    <svg className="sparkline" viewBox={`0 0 ${width} ${height}`} preserveAspectRatio="none">
      <polyline points={points} fill="none" stroke="currentColor" strokeWidth="2" />
    </svg>
  )
}

function PricePanel() {
  const { isPolling, history, lastError, errorCount } = useAppSelector(selectPrice)
  const dispatch = useAppDispatch()

  const current = history.at(-1)
  const previous = history.at(-2)
  const change = current !== undefined && previous !== undefined ? current - previous : 0

  return (
    <section className="panel narrow">
      <div className="row">
        <button onClick={() => dispatch(pollingStarted())} disabled={isPolling}>
          Start polling
        </button>
        <button onClick={() => dispatch(pollingStopped())} disabled={!isPolling}>
          Stop
        </button>
        <span className={`pill ${isPolling ? 'on' : ''}`}>{isPolling ? '● live' : 'stopped'}</span>
      </div>

      <div className="price">
        <span className="muted">ACME</span>{' '}
        <span className="big">{current !== undefined ? `$${current.toFixed(2)}` : '—'}</span>{' '}
        {change !== 0 && (
          <span className={change > 0 ? 'up' : 'down'}>
            {change > 0 ? '▲' : '▼'} {Math.abs(change).toFixed(2)}
          </span>
        )}
      </div>

      <Sparkline values={history} />

      <p className="muted">
        Failed requests: {errorCount}
        {lastError && <span className="error"> · last: {lastError}</span>}
      </p>
    </section>
  )
}

export function PriceLesson() {
  return (
    <Lesson
      title="5. Polling — take, race and cancellation"
      intro={
        <p>
          A saga that waits for <code>pollingStarted</code>, then fetches a price every second until{' '}
          <code>pollingStopped</code> arrives. <code>race</code> runs both at once, and when stop wins
          the polling loop is cancelled automatically.
        </p>
      }
      files={['src/features/price/priceSlice.ts', 'src/features/price/priceSaga.ts']}
      tryIt={[
        'Start polling, then switch to another lesson. The Action Log keeps filling up because sagas aren’t tied to components the way useEffect is.',
        'Open the browser console and click Stop to see the cleanup message from the finally block.',
        'About 1 in 10 requests fails on purpose. The loop keeps going because the error is caught inside it.',
        'Exercise: add a “Polling speed” select that dispatches an action, and read the value with select() inside pollPrice.',
      ]}
    >
      <PricePanel />
    </Lesson>
  )
}
