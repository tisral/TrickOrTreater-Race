import { createSlice, type PayloadAction } from '@reduxjs/toolkit'
import type { RootState } from '../../app/store'

interface PriceState {
  isPolling: boolean
  history: number[] // most recent last
  lastError: string | null
  errorCount: number
}

const initialState: PriceState = {
  isPolling: false,
  history: [],
  lastError: null,
  errorCount: 0,
}

const MAX_HISTORY = 30

export const priceSlice = createSlice({
  name: 'price',
  initialState,
  reducers: {
    pollingStarted(state) {
      state.isPolling = true
    },
    pollingStopped(state) {
      state.isPolling = false
    },
    priceReceived(state, action: PayloadAction<number>) {
      state.history.push(action.payload)
      if (state.history.length > MAX_HISTORY) state.history.shift()
      state.lastError = null
    },
    priceFailed(state, action: PayloadAction<string>) {
      state.lastError = action.payload
      state.errorCount += 1
    },
  },
})

export const { pollingStarted, pollingStopped, priceReceived, priceFailed } = priceSlice.actions

export const selectPrice = (state: RootState) => state.price

export default priceSlice.reducer
