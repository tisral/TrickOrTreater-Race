/**
 * LESSON 4 — Search-as-you-type state
 * ===================================
 * `keystrokes` and `apiCalls` are only here so the UI can show how much
 * work the saga saved by debouncing.
 */
import { createSlice, type PayloadAction } from '@reduxjs/toolkit'
import type { RootState } from '../../app/store'
import type { Product } from '../../api/fakeApi'

interface SearchState {
  query: string
  results: Product[]
  status: 'idle' | 'waiting' | 'loading' | 'succeeded' | 'failed'
  error: string | null
  keystrokes: number
  apiCalls: number
}

const initialState: SearchState = {
  query: '',
  results: [],
  status: 'idle',
  error: null,
  keystrokes: 0,
  apiCalls: 0,
}

export const searchSlice = createSlice({
  name: 'search',
  initialState,
  reducers: {
    // Dispatched by the input on every keystroke.
    queryChanged(state, action: PayloadAction<string>) {
      state.query = action.payload
      state.keystrokes += 1
      state.status = action.payload.trim() ? 'waiting' : 'idle'
      if (!action.payload.trim()) state.results = []
    },
    // The next three are dispatched by the saga.
    searchStarted(state) {
      state.status = 'loading'
      state.apiCalls += 1
    },
    searchSucceeded(state, action: PayloadAction<Product[]>) {
      state.status = 'succeeded'
      state.results = action.payload
    },
    searchFailed(state, action: PayloadAction<string>) {
      state.status = 'failed'
      state.error = action.payload
    },
  },
})

export const { queryChanged, searchStarted, searchSucceeded, searchFailed } = searchSlice.actions

export const selectSearch = (state: RootState) => state.search

export default searchSlice.reducer
