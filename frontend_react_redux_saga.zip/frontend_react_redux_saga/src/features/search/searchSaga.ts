/**
 * LESSON 4 — Debouncing with takeLatest + delay
 * =============================================
 * We want to search as the user types, but NOT hit the API on every keystroke.
 *
 * Without sagas you'd juggle setTimeout/clearTimeout in a useEffect, plus an
 * "ignore stale response" flag so a slow old request can't overwrite a newer one.
 *
 * With sagas it's two lines in the worker:
 *
 *   yield delay(400)               // wait 400ms...
 *   yield call(api.search, query)  // ...then search
 *
 * plus `takeLatest`. When a new keystroke arrives, takeLatest CANCELS the
 * previous worker wherever it is:
 *   - still in delay()  -> the search never happens (that's the debounce)
 *   - already in call() -> its result is ignored (no stale responses)
 */
import type { PayloadAction } from '@reduxjs/toolkit'
import type { SagaIterator } from 'redux-saga'
import { call, delay, put, takeLatest } from 'redux-saga/effects'

import * as api from '../../api/fakeApi'
import type { Product } from '../../api/fakeApi'
import { queryChanged, searchFailed, searchStarted, searchSucceeded } from './searchSlice'

const DEBOUNCE_MS = 400

// The worker receives the action that triggered it, so it can read the payload.
export function* handleQueryChanged(action: PayloadAction<string>): SagaIterator {
  const query = action.payload.trim()
  if (!query) return // the reducer already cleared the results

  yield delay(DEBOUNCE_MS)

  // If we get here, the user stopped typing for 400ms.
  yield put(searchStarted())
  try {
    const results: Product[] = yield call(api.searchProducts, query)
    yield put(searchSucceeded(results))
  } catch (error) {
    yield put(searchFailed(error instanceof Error ? error.message : 'Unknown error'))
  }
}

export function* searchSaga(): SagaIterator {
  yield takeLatest(queryChanged.type, handleQueryChanged)

  // FYI: redux-saga also has a built-in helper that does something similar:
  //   yield debounce(400, queryChanged.type, worker)
  // but it doesn't cancel a request that's already in flight. takeLatest + delay does both.
}
