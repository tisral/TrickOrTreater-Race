import { useAppDispatch, useAppSelector } from '../../app/hooks'
import { Lesson } from '../../components/Lesson'
import { queryChanged, selectSearch } from './searchSlice'

function SearchPanel() {
  const { query, results, status, error, keystrokes, apiCalls } = useAppSelector(selectSearch)
  const dispatch = useAppDispatch()

  return (
    <section className="panel narrow">
      <input
        value={query}
        onChange={(e) => dispatch(queryChanged(e.target.value))}
        placeholder="Search fruit… try “berry”"
        autoFocus
      />

      <div className="stats">
        <div>
          <span className="big">{keystrokes}</span>
          <span className="muted">keystrokes</span>
        </div>
        <div>
          <span className="big">{apiCalls}</span>
          <span className="muted">API calls</span>
        </div>
        <div>
          <code>{status}</code>
          <span className="muted">status</span>
        </div>
      </div>

      {status === 'failed' && <p className="error">{error}</p>}
      {status === 'succeeded' && results.length === 0 && <p className="muted">No matches.</p>}

      <ul className="result-list">
        {results.map((p) => (
          <li key={p.id}>
            {p.name} <span className="muted">${p.price.toFixed(2)}</span>
          </li>
        ))}
      </ul>
    </section>
  )
}

export function SearchLesson() {
  return (
    <Lesson
      title="4. Debounced search — takeLatest + delay"
      intro={
        <p>
          Search as you type without calling the API on every keystroke. <code>takeLatest</code>{' '}
          cancels the previous worker each time a new <code>queryChanged</code> action arrives, so
          only the last one survives its 400&nbsp;ms <code>delay</code>.
        </p>
      }
      files={['src/features/search/searchSlice.ts', 'src/features/search/searchSaga.ts']}
      tryIt={[
        'Type “blueberry” quickly. Compare the keystroke count with the API call count.',
        'Type slowly, one letter every half second. Every keystroke now triggers a call.',
        'Change takeLatest to takeEvery in searchSaga.ts. The debounce stops working because nothing gets cancelled.',
      ]}
    >
      <SearchPanel />
    </Lesson>
  )
}
