import { useState, type FormEvent } from 'react'
import { useAppDispatch, useAppSelector } from '../../app/hooks'
import { Lesson } from '../../components/Lesson'
import {
  addTodo,
  clearCompleted,
  removeTodo,
  selectFilter,
  selectTodoStats,
  selectVisibleTodos,
  setFilter,
  toggleTodo,
  type Filter,
} from './todosSlice'

function AddTodoForm() {
  // Not everything belongs in Redux! The text being typed is local UI state
  // that no other component cares about, so plain useState is the right tool.
  const [text, setText] = useState('')
  const dispatch = useAppDispatch()

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault()
    if (!text.trim()) return
    dispatch(addTodo(text.trim()))
    setText('')
  }

  return (
    <form onSubmit={handleSubmit} className="row">
      <input value={text} onChange={(e) => setText(e.target.value)} placeholder="What needs doing?" />
      <button type="submit">Add</button>
    </form>
  )
}

function FilterButtons() {
  const filter = useAppSelector(selectFilter)
  const dispatch = useAppDispatch()
  const filters: Filter[] = ['all', 'active', 'done']
  return (
    <div className="row">
      {filters.map((f) => (
        <button key={f} className={f === filter ? 'active' : ''} onClick={() => dispatch(setFilter(f))}>
          {f}
        </button>
      ))}
    </div>
  )
}

function TodoList() {
  const todos = useAppSelector(selectVisibleTodos)
  const dispatch = useAppDispatch()

  if (todos.length === 0) return <p className="muted">Nothing here.</p>

  return (
    <ul className="todo-list">
      {todos.map((todo) => (
        <li key={todo.id}>
          <label className={todo.done ? 'done' : ''}>
            <input type="checkbox" checked={todo.done} onChange={() => dispatch(toggleTodo(todo.id))} />
            {todo.text}
          </label>
          <button className="link" onClick={() => dispatch(removeTodo(todo.id))} aria-label="Delete">
            ✕
          </button>
        </li>
      ))}
    </ul>
  )
}

/** A separate component far away in the tree can read the same state. No prop drilling. */
function TodoStats() {
  const { total, done, active } = useAppSelector(selectTodoStats)
  const dispatch = useAppDispatch()
  return (
    <div className="row muted">
      <span>
        {active} active · {done} done · {total} total
      </span>
      <button className="link" onClick={() => dispatch(clearCompleted())} disabled={done === 0}>
        Clear completed
      </button>
    </div>
  )
}

export function TodosLesson() {
  return (
    <Lesson
      title="2. Todos — payloads and selectors"
      intro={
        <p>
          A todo list with actions that carry data, a <code>prepare</code> callback that generates ids,
          and <code>createSelector</code> for derived data like the filtered list and the counts.
        </p>
      }
      files={['src/features/todos/todosSlice.ts', 'src/features/todos/TodosLesson.tsx']}
      tryIt={[
        'Add, toggle and delete todos while watching the Action Log. Each action shows the payload it carried.',
        'The form input uses plain useState. Ask yourself whether another component needs a piece of state before putting it in Redux.',
        'Find where the todo id is generated, and why it isn’t generated inside the reducer.',
      ]}
    >
      <section className="panel narrow">
        <AddTodoForm />
        <FilterButtons />
        <TodoList />
        <TodoStats />
      </section>
    </Lesson>
  )
}
