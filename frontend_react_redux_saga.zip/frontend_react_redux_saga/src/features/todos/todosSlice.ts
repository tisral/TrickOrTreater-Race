/**
 * LESSON 2 — Arrays, payloads and derived data
 * ============================================
 * New ideas compared to the counter:
 *   - actions that carry data (`payload`)
 *   - a `prepare` callback to build the payload (e.g. generate an id)
 *   - `createSelector` for derived data (filtered lists, counts), memoized
 */
import { createSelector, createSlice, nanoid, type PayloadAction } from '@reduxjs/toolkit'
import type { RootState } from '../../app/store'

export interface Todo {
  id: string
  text: string
  done: boolean
}

export type Filter = 'all' | 'active' | 'done'

interface TodosState {
  items: Todo[]
  filter: Filter
}

const initialState: TodosState = {
  items: [
    { id: 'seed-1', text: 'Read counterSlice.ts', done: true },
    { id: 'seed-2', text: 'Read todosSlice.ts', done: false },
    { id: 'seed-3', text: 'Learn sagas in lesson 3', done: false },
  ],
  filter: 'all',
}

export const todosSlice = createSlice({
  name: 'todos',
  initialState,
  reducers: {
    addTodo: {
      // Reducers must be "pure": same input -> same output, no randomness.
      // So we generate the random id in `prepare`, which runs when the action
      // is CREATED, before it reaches the reducer.
      //   addTodo('Buy milk') -> { type: 'todos/addTodo', payload: { id: 'x7f..', text: 'Buy milk', done: false } }
      prepare(text: string) {
        return { payload: { id: nanoid(), text, done: false } }
      },
      reducer(state, action: PayloadAction<Todo>) {
        state.items.push(action.payload)
      },
    },
    toggleTodo(state, action: PayloadAction<string>) {
      const todo = state.items.find((t) => t.id === action.payload)
      if (todo) todo.done = !todo.done
    },
    removeTodo(state, action: PayloadAction<string>) {
      state.items = state.items.filter((t) => t.id !== action.payload)
    },
    clearCompleted(state) {
      state.items = state.items.filter((t) => !t.done)
    },
    setFilter(state, action: PayloadAction<Filter>) {
      state.filter = action.payload
    },
  },
})

export const { addTodo, toggleTodo, removeTodo, clearCompleted, setFilter } = todosSlice.actions

// --- Selectors -------------------------------------------------------------

export const selectTodos = (state: RootState) => state.todos.items
export const selectFilter = (state: RootState) => state.todos.filter

// ⚠️ Why createSelector?
// `useAppSelector` re-renders the component when the selector returns a NEW value
// (compared with ===). `todos.filter(...)` returns a new array every time,
// so a plain selector would re-render on EVERY action, even unrelated ones.
// `createSelector` memoizes: it only recomputes when its inputs change.
export const selectVisibleTodos = createSelector(
  [selectTodos, selectFilter], // input selectors
  (todos, filter) => {
    // output selector: only runs when `todos` or `filter` changed
    if (filter === 'active') return todos.filter((t) => !t.done)
    if (filter === 'done') return todos.filter((t) => t.done)
    return todos
  },
)

export const selectTodoStats = createSelector([selectTodos], (todos) => {
  const done = todos.filter((t) => t.done).length
  return { total: todos.length, done, active: todos.length - done }
})

export default todosSlice.reducer
