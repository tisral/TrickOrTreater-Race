/**
 * LESSON 3 — Your first saga
 * ==========================
 * A saga is a GENERATOR function (note the `function*`). Inside it you `yield`
 * EFFECTS: plain objects that describe what you want to happen:
 *
 *   yield call(api.fetchUsers)   -> "please call this function and give me the result"
 *   yield put(someAction())      -> "please dispatch this action"
 *   yield select(selector)       -> "please read this from the state"
 *
 * The saga middleware runs these instructions and resumes the generator with
 * the result. It reads like synchronous code, but it's async under the hood:
 *
 *   const users = yield call(api.fetchUsers)   // pauses here until the Promise resolves
 *
 * Why describe effects instead of calling functions directly? Because then a
 * test can step through the saga and check each instruction WITHOUT running a
 * real API call. See usersSaga.test.ts.
 *
 * A typical saga file has two parts:
 *   1. a WORKER saga that does the work for one action
 *   2. a WATCHER saga that listens for actions and starts workers
 */
import type { SagaIterator } from 'redux-saga'
import { call, put, select, takeLatest } from 'redux-saga/effects'

import * as api from '../../api/fakeApi'
import type { User } from '../../api/fakeApi'
import {
  fetchUsersFailed,
  fetchUsersRequested,
  fetchUsersSucceeded,
  selectSimulateError,
} from './usersSlice'

// 1. WORKER: runs once per fetchUsersRequested action.
export function* fetchUsersWorker(): SagaIterator {
  try {
    // `select` reads from the store. Here it reads the "simulate error" checkbox.
    const shouldFail: boolean = yield select(selectSimulateError)

    // `call` runs a function that returns a Promise and waits for it.
    // Arguments go after the function: call(fn, arg1, arg2) — NOT call(fn(arg1)).
    //
    // TypeScript tip: TS can't infer what a `yield` returns in a saga,
    // so annotate the variable yourself (`const users: User[] = ...`).
    const users: User[] = yield call(api.fetchUsers, { shouldFail })

    // `put` dispatches an action, the same as calling dispatch() in a component.
    yield put(fetchUsersSucceeded(users))
  } catch (error) {
    // If the Promise rejects, `call` throws here, like `await` would.
    yield put(fetchUsersFailed(error instanceof Error ? error.message : 'Unknown error'))
  }
}

// 2. WATCHER: listens for actions and starts a worker for each one.
export function* usersSaga(): SagaIterator {
  // takeLatest: if a new fetchUsersRequested arrives while a previous fetch is
  // still running, CANCEL the old one and only keep the latest.
  //
  // Other options:
  //   takeEvery   -> run a worker for every action, all in parallel
  //   takeLeading -> ignore new actions while one is still running
  yield takeLatest(fetchUsersRequested.type, fetchUsersWorker)
}
