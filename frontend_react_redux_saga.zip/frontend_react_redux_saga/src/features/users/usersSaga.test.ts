/**
 * Testing a saga step by step.
 *
 * A saga yields effect DESCRIPTIONS (plain objects), so a test can:
 *   1. call gen.next() to get the next effect
 *   2. check it's the effect we expect
 *   3. feed back a fake result with gen.next(fakeResult)
 *
 * The real API is never called, and there's nothing to mock.
 */
import { describe, expect, it } from 'vitest'
import { call, put, select } from 'redux-saga/effects'

import * as api from '../../api/fakeApi'
import { fetchUsersWorker } from './usersSaga'
import { fetchUsersFailed, fetchUsersSucceeded, selectSimulateError } from './usersSlice'

const fakeUsers = [{ id: 99, name: 'Test User', email: 'test@example.com' }]

describe('fetchUsersWorker', () => {
  it('reads state, calls the API, then dispatches success', () => {
    const gen = fetchUsersWorker()

    // Step 1: the saga asks to read `simulateError` from the store.
    expect(gen.next().value).toEqual(select(selectSimulateError))

    // Step 2: we answer "false", and the saga asks to call the API with it.
    expect(gen.next(false).value).toEqual(call(api.fetchUsers, { shouldFail: false }))

    // Step 3: we answer with fake users, and the saga dispatches success.
    expect(gen.next(fakeUsers).value).toEqual(put(fetchUsersSucceeded(fakeUsers)))

    // Step 4: done.
    expect(gen.next().done).toBe(true)
  })

  it('dispatches failure when the API throws', () => {
    const gen = fetchUsersWorker()
    gen.next() // select
    gen.next(true) // call

    // Simulate the API's Promise rejecting.
    expect(gen.throw(new Error('boom')).value).toEqual(put(fetchUsersFailed('boom')))
    expect(gen.next().done).toBe(true)
  })
})
