import { useAppDispatch, useAppSelector } from '../../app/hooks'
import { Lesson } from '../../components/Lesson'
import {
  fetchUsersRequested,
  selectSimulateError,
  selectUsers,
  selectUsersError,
  selectUsersStatus,
  simulateErrorToggled,
} from './usersSlice'

function UsersPanel() {
  const users = useAppSelector(selectUsers)
  const status = useAppSelector(selectUsersStatus)
  const error = useAppSelector(selectUsersError)
  const simulateError = useAppSelector(selectSimulateError)
  const dispatch = useAppDispatch()

  // Notice: the component does NOT fetch, use useEffect, or know about the API.
  // It just says "users were requested" and renders whatever is in the store.
  return (
    <section className="panel narrow">
      <div className="row">
        <button onClick={() => dispatch(fetchUsersRequested())} disabled={status === 'loading'}>
          {status === 'loading' ? 'Loading…' : 'Fetch users'}
        </button>
        <label className="row">
          <input type="checkbox" checked={simulateError} onChange={() => dispatch(simulateErrorToggled())} />
          Make the request fail
        </label>
      </div>

      <p className="muted">
        status: <code>{status}</code>
      </p>

      {status === 'failed' && <p className="error">Error: {error}</p>}

      {users.length > 0 && (
        <ul className="user-list">
          {users.map((u) => (
            <li key={u.id}>
              <strong>{u.name}</strong> <span className="muted">{u.email}</span>
            </li>
          ))}
        </ul>
      )}
    </section>
  )
}

export function UsersLesson() {
  return (
    <Lesson
      title="3. Your first saga — fetching data"
      intro={
        <>
          <p>
            The component dispatches <code>fetchUsersRequested()</code> and that’s all it does. A saga
            listening for that action calls the API, then dispatches <code>fetchUsersSucceeded</code>{' '}
            or <code>fetchUsersFailed</code>. The component never awaits anything.
          </p>
          <ol className="flow">
            <li>
              <b>UI</b> <code>dispatch(fetchUsersRequested())</code>
            </li>
            <li>
              <b>reducer</b> sees it first → <code>status = 'loading'</code>
            </li>
            <li>
              <b>saga</b> sees it next → <code>select</code> → <code>call(api.fetchUsers)</code> →{' '}
              <code>put(fetchUsersSucceeded(users))</code>
            </li>
            <li>
              <b>reducer</b> → <code>status = 'succeeded'</code>, <code>items = users</code>
            </li>
            <li>
              <b>UI</b> re-renders with the users
            </li>
          </ol>
        </>
      }
      files={[
        'src/features/users/usersSlice.ts',
        'src/features/users/usersSaga.ts',
        'src/features/users/usersSaga.test.ts',
        'src/app/rootSaga.ts',
      ]}
      tryIt={[
        'Click Fetch users and watch the Action Log: one action from the UI, then one from the saga about a second later.',
        'Tick “Make the request fail” and fetch again to see the failure path.',
        'In usersSaga.ts, change takeLatest to takeEvery and remove the button’s disabled prop. Click many times and compare the Action Log.',
        'Run npm test and read usersSaga.test.ts to see how sagas are tested without a real API.',
      ]}
    >
      <UsersPanel />
    </Lesson>
  )
}
