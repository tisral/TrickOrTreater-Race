/**
 * LESSON 3 — State for async data
 * ===============================
 * Reducers must be synchronous and pure, so they can't fetch anything.
 * The usual pattern is three actions per request:
 *
 *   fetchUsersRequested  -> dispatched by the UI         -> reducer sets status = 'loading'
 *   fetchUsersSucceeded  -> dispatched by the SAGA       -> reducer stores the data
 *   fetchUsersFailed     -> dispatched by the SAGA       -> reducer stores the error
 *
 * The slice never fetches. It only describes how state changes. The saga
 * (usersSaga.ts) does the actual work.
 */
import { createSlice, type PayloadAction } from '@reduxjs/toolkit'
import type { RootState } from '../../app/store'
import type { User } from '../../api/fakeApi'

interface UsersState {
  items: User[]
  status: 'idle' | 'loading' | 'succeeded' | 'failed'
  error: string | null
  simulateError: boolean
}

const initialState: UsersState = {
  items: [],
  status: 'idle',
  error: null,
  simulateError: false,
}

export const usersSlice = createSlice({
  name: 'users',
  initialState,
  reducers: {
    // The UI dispatches this. The reducer runs FIRST (sets loading),
    // then the saga middleware sees the same action and starts fetching.
    fetchUsersRequested(state) {
      state.status = 'loading'
      state.error = null
    },
    fetchUsersSucceeded(state, action: PayloadAction<User[]>) {
      state.status = 'succeeded'
      state.items = action.payload
    },
    fetchUsersFailed(state, action: PayloadAction<string>) {
      state.status = 'failed'
      state.error = action.payload
    },
    simulateErrorToggled(state) {
      state.simulateError = !state.simulateError
    },
  },
})

export const { fetchUsersRequested, fetchUsersSucceeded, fetchUsersFailed, simulateErrorToggled } =
  usersSlice.actions

export const selectUsers = (state: RootState) => state.users.items
export const selectUsersStatus = (state: RootState) => state.users.status
export const selectUsersError = (state: RootState) => state.users.error
export const selectSimulateError = (state: RootState) => state.users.simulateError

export default usersSlice.reducer
