/**
 * THE STORE
 * =========
 * With Context you usually have many providers, each holding its own
 * `useState`/`useReducer`. In Redux there is ONE store that holds ALL the
 * global state as one big object:
 *
 *   {
 *     counter:   { value: 0, step: 1 },
 *     todos:     { items: [...], filter: 'all' },
 *     users:     { items: [], status: 'idle', ... },
 *     ...
 *   }
 *
 * Each top-level key is owned by one "slice" reducer (see features/*Slice.ts).
 */
import { configureStore } from '@reduxjs/toolkit'
import createSagaMiddleware from 'redux-saga'

import counterReducer from '../features/counter/counterSlice'
import todosReducer from '../features/todos/todosSlice'
import usersReducer from '../features/users/usersSlice'
import searchReducer from '../features/search/searchSlice'
import priceReducer from '../features/price/priceSlice'
import actionLogReducer from '../features/actionLog/actionLogSlice'
import rootSaga from './rootSaga'

// 1. Create the saga middleware. Middleware sits between `dispatch(action)`
//    and the reducers, so sagas get to see every action that is dispatched.
const sagaMiddleware = createSagaMiddleware()

// 2. Build the store. `configureStore` (from Redux Toolkit) also wires up the
//    Redux DevTools browser extension for you — install it, it's amazing for learning.
export const store = configureStore({
  reducer: {
    counter: counterReducer,
    todos: todosReducer,
    users: usersReducer,
    search: searchReducer,
    price: priceReducer,
    actionLog: actionLogReducer,
  },
  // Redux Toolkit ships with "thunk" middleware for async logic by default.
  // We're using sagas instead, so we turn thunks off and add the saga middleware.
  middleware: (getDefaultMiddleware) =>
    getDefaultMiddleware({ thunk: false }).concat(sagaMiddleware),
})

// 3. Start the sagas. This must happen AFTER the store is created.
sagaMiddleware.run(rootSaga)

// 4. TypeScript types inferred from the store itself — no need to write them by hand.
//    RootState = the shape of the whole state tree.
//    AppDispatch = the type of `store.dispatch`.
export type RootState = ReturnType<typeof store.getState>
export type AppDispatch = typeof store.dispatch
