/**
 * Typed versions of the react-redux hooks.
 *
 * Use these everywhere instead of the plain `useDispatch` / `useSelector`,
 * so TypeScript knows the shape of your state:
 *
 *   const count = useAppSelector((state) => state.counter.value)  // number ✅
 *
 * Context analogy:
 *   useContext(MyContext)        -> useAppSelector(state => state.something)
 *   the setter/dispatch you get  -> useAppDispatch()
 */
import { useDispatch, useSelector } from 'react-redux'
import type { AppDispatch, RootState } from './store'

export const useAppDispatch = useDispatch.withTypes<AppDispatch>()
export const useAppSelector = useSelector.withTypes<RootState>()
