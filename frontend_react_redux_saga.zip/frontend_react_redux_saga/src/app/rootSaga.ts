/**
 * The root saga starts every feature saga in parallel.
 * It's the saga equivalent of `combineReducers`.
 */
import type { SagaIterator } from 'redux-saga'
import { all, fork } from 'redux-saga/effects'

import { usersSaga } from '../features/users/usersSaga'
import { searchSaga } from '../features/search/searchSaga'
import { priceSaga } from '../features/price/priceSaga'

export default function* rootSaga(): SagaIterator {
  // `fork` starts a saga without waiting for it to finish (non-blocking).
  // `all` groups the forks together. Each feature saga loops forever listening
  // for actions, so the root saga stays alive for the whole app.
  yield all([fork(usersSaga), fork(searchSaga), fork(priceSaga)])
}
