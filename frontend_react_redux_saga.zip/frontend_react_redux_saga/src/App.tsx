import { useState } from 'react'

import { ActionLog } from './features/actionLog/ActionLog'
import { CounterLesson } from './features/counter/CounterLesson'
import { TodosLesson } from './features/todos/TodosLesson'
import { UsersLesson } from './features/users/UsersLesson'
import { SearchLesson } from './features/search/SearchLesson'
import { PriceLesson } from './features/price/PriceLesson'

const LESSONS = [
  { id: 'counter', label: '1. Counter', topic: 'Redux basics', Component: CounterLesson },
  { id: 'todos', label: '2. Todos', topic: 'Payloads & selectors', Component: TodosLesson },
  { id: 'users', label: '3. Fetch users', topic: 'First saga', Component: UsersLesson },
  { id: 'search', label: '4. Search', topic: 'takeLatest + delay', Component: SearchLesson },
  { id: 'price', label: '5. Polling', topic: 'take, race, cancel', Component: PriceLesson },
] as const

type LessonId = (typeof LESSONS)[number]['id']

export default function App() {
  // Which tab is open is local UI state, so useState is enough here.
  const [current, setCurrent] = useState<LessonId>('counter')
  const { Component } = LESSONS.find((l) => l.id === current)!

  return (
    <div className="layout">
      <header className="top">
        <h1>React + Redux Toolkit + Redux Saga</h1>
        <nav>
          {LESSONS.map((l) => (
            <button key={l.id} className={l.id === current ? 'active' : ''} onClick={() => setCurrent(l.id)}>
              <span>{l.label}</span>
              <small>{l.topic}</small>
            </button>
          ))}
        </nav>
      </header>

      <main>
        <Component />
      </main>

      <ActionLog />
    </div>
  )
}
